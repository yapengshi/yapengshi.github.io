Yapeng Shi's resume cn_en generated via Overleaf

### Build CV using Overleaf

icon pdf from "https://www.cleanpng.com/"

Yapeng_Resume.png

### License

Format is from Overleaf template "https://www.overleaf.com/latex/templates/1-dot-5-column-cv/rpcbqtrsgbxm".